package in.ashokit.dao;

public class ContactsDao {
	
	
	public boolean saveUserData()
	{
		
		boolean saveUserData =false;
		
		
		
		
		
		
		
		
		
		
		
		
		return saveUserData;
		
	}
	
	
	
	

}
